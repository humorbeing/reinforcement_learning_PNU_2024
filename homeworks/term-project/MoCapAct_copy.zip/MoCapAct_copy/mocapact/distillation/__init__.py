"""
Files used for training the multi-clip policy and GPT policy.
Also constains the script for rolling out experts to generate
the MoCapAct dataset.
"""