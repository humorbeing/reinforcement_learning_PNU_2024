"""
Files used to train the clip-tracking experts.
"""
