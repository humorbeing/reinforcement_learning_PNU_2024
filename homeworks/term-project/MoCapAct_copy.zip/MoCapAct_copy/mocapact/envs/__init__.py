"""
Files for defining the Gym environments used in MoCapAct.
The base class is a wrapper that turns a dm_control environment
into a Gym environment.
"""